var maxTime = 120;
var timeStep = 15;
var app = angular.module('App',['ngMaterial', 'ngMessages','ngRoute','timer']);
// configure our routes
app.config(function($routeProvider) {
    $routeProvider

        // route for the home page
        .when('/', {
            templateUrl : '../pages/home.html',


        })
        // route for the signin page
        .when('/signin', {
            templateUrl : '../pages/signin.html'
        })

        // route for the signup page
        .when('/signup', {
            templateUrl : '../pages/signup.html'
        })
        .when('/clientDashboard', {
	        templateUrl : '../pages/clientDashboard.html'
        })
        .when('/parkingSlot', {
            templateUrl : '../pages/parkingSlot.html'
        });
});

// app.controller('SignUpCtrl', function($scope) {
//     $scope.open =function  () {
//         $scope.url = "../pages/signin.html";
//     }

// });
/* Parking */
app.controller('chooseSlotCtrl', function($scope,$rootScope,$mdDialog,$location,$document) {

	$scope.slots = [
		{id: 0,plate: '31 ABC',slotNumber: 'AB01'},
		{id: 1,plate: '32 ABC',slotNumber: 'AB02'},
		{id: 2,plate: '33 ABC',slotNumber: 'AB03'},
		{id: 3,plate: '34 ABC',slotNumber: 'AB04'},
		{id: 4,plate: '35 ABC',slotNumber: 'AB05'},
		{id: 5,plate: '36 ABC',slotNumber: 'AB06'},
		{id: 6,plate: '37 ABC',slotNumber: 'AB07'},
		{id: 7,plate: '38 ABC',slotNumber: 'AB08'},
		{id: 8,plate: '39 ABC',slotNumber: 'AB09'},
		{id: 9,plate: '40 ABC',slotNumber: 'AB10'}
	];


	/* show slot and select time*/
	$scope.showAdvanced = function(slotId, plate) {
		/*console.log(slotId);*/

		// check if there is 'disable' class
		var slotEl = getElemBySlotId(slotId);
		if (slotEl && !slotEl.hasClass('disable')) {
			$mdDialog.show({
		      controller: PurchaseController,
		      templateUrl: '../pages/dialog1.tmpl.html',
		      locals: {
	           slotSelected: slotId,
	           clientPlate: plate

	         }
	    });
		}

  };/*End showAdvanced*/


});/*END chooseSlotCtrl*/


app.controller('extendTimeCtrl', function ($scope, $rootScope,$mdDialog) {

	  	/* show slot and select time*/
	$scope.showExtend = function(slotIdEx, curentPay,remainTime) {
		if((remainTime+timeStep)<=maxTime) {
			$mdDialog.show({
		      controller: ExtendController,
		      templateUrl: '../pages/extend.tmpl.html',
		      locals: {
	           slotEx: slotIdEx,
	           curentPayEx: curentPay,
	           remainTimeEx: remainTime
	         }
	    });
    }else{
	   $mdDialog.show(
	      $mdDialog.alert()
	        .parent(angular.element(document.querySelector('#popupContainer')))
	        .clickOutsideToClose(true)
	        .title('This is an alert title')
	        .htmlContent('You can not extend time now.')
	        .ariaLabel('Alert Extend Time')
	        .ok('Got it!')
	        .openFrom('#btn-showExtend')
	        .theme("warn")
    	);
    }
  };/*End showExtend*/

});/*End extendTimeCtrl*/

function getElemBySlotId(slotId) {
	var slotSelector ='#'+slotId;
	var myEl = angular.element( document.querySelector(slotSelector) );

	return myEl;
}/*End getElemBySlotId*/


function PurchaseController($scope, $mdDialog, slotSelected,clientPlate) {
	console.log('cont: PurchaseController' );
	$scope.slotSelected= slotSelected;
	$scope.plate = clientPlate;
	$scope.minute = 30;
	$scope.money = 0.255;
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  };
  $scope.answer = function(finalSlot,money,minute) {
    $mdDialog.show({
    	clickOutsideToClose: true,
    	controller: PayController,
    	templateUrl: '../pages/dialog2.tmpl.html',
      locals: {
         fSlot: finalSlot,
         pay: money,
         clientMinute: minute
       }
    });
  };/*end answer*/

}/*Eng PurchaseController*/

function PayController ($scope,$rootScope,$location,$mdDialog,fSlot,pay,clientMinute) {
	console.log('cont: PAYController' );
	console.log('slot: '+fSlot );
	$rootScope.slotPurchase = fSlot;
	$rootScope.timePurchase = clientMinute;
	$rootScope.totalPay = pay;
	$scope.fSlot = fSlot;

	$scope.pay= pay;
	$scope.yes = function(slotId) {

		var myEl = getElemBySlotId(slotId);
		myEl.addClass('disable');
		$location.path("/");
		document.getElementById("defaultPage").classList.add("app");
		$mdDialog.cancel();
	}/*End yes*/
}/*END PayController */


function ExtendController ($scope,$rootScope,$mdDialog,slotEx,curentPayEx,remainTimeEx) {
	$scope.slotExtend = slotEx;
	$scope.totalPayAfterExtend = curentPayEx + (0.0085*timeStep);
	$scope.curentPayExtend = curentPayEx;
	$scope.currentRemainTime = remainTimeEx;
	$scope.minuteExtend = 30;
  $scope.cancel = function() {
    $mdDialog.cancel();
  };
  $scope.acceptExtend = function (ttpay,ttminute) {
  	totalPayment = ttpay;
  	totalTimePurchase = ttminute;
  	console.log('payAfterEx: '+ttpay);
  	console.log('timeAfterEx: '+ttminute);
  	$mdDialog.cancel();

  }/*End acceptExtend*/
}/*End ExtendController*/